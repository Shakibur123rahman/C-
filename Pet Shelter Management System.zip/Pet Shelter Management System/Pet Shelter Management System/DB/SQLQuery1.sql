create table LOGIN
(username varchar(50) not null,
pass nvarchar(50) not null
)

INSERT INTO LOGIN VALUES ('sourav', '0000');
select * from LOGIN;
